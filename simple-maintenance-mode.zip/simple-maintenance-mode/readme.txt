=== Simple Maintenance Mode ===
Contributors: YOUR_GITHUB_USERNAME
Tags: maintenance, coming soon, site lockout, maintenance mode
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds a simple admin toggle to enable/disable maintenance mode for non-logged-in visitors.

== Description ==

Use this plugin to easily lock out your site with a “Site Under Maintenance” message, while admins can still edit everything.

== Installation ==

1. Upload the plugin to `/wp-content/plugins/`
2. Activate through the 'Plugins' menu
3. Go to Settings → Maintenance Mode to toggle it

== Changelog ==

= 1.0 =
* Initial MVP released 🚧
